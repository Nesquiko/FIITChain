# FIITChain

A blockchain implementation in Rust for Assignment 1 on Digital Currencies and
Blockchain course on FIIT STU Bratislava
